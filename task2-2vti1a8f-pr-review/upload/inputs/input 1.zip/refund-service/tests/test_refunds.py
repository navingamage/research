import pytest

from refund_service.refunds import RefundService
from tests.fakes import FakeProcessor


def test_refund_succeeds():
    processor = FakeProcessor()
    result = RefundService(processor).issue_refund("pay_100", 1500)
    assert result["status"] == "succeeded"
    assert processor.refunds == [("pay_100", 1500)]


def test_rejects_zero_amount():
    with pytest.raises(ValueError):
        RefundService(FakeProcessor()).issue_refund("pay_100", 0)


def test_retries_after_timeout():
    processor = FakeProcessor(fail_first_calls=1)
    result = RefundService(processor).issue_refund("pay_200", 2500)
    assert result["status"] == "succeeded"
    assert processor.calls == 2
