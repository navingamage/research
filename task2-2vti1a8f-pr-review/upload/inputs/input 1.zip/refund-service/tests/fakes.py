from refund_service.errors import InvalidRefund, ProcessorTimeout


class FakeProcessor:
    """Stands in for the payment processor in tests.

    fail_first_calls: the first N calls time out before the refund is made.
    lose_first_responses: the first N calls make the refund, then time out
        before we get the answer back (the processor did the work, we just
        never heard about it).
    reject: every call is rejected as an invalid refund.

    Like the real processor, a repeated idempotency_key is not refunded again.
    """

    def __init__(self, fail_first_calls=0, lose_first_responses=0, reject=False):
        self.fail_first_calls = fail_first_calls
        self.lose_first_responses = lose_first_responses
        self.reject = reject
        self.calls = 0
        self.refunds = []
        self._seen_keys = set()

    def refund(self, payment_id, amount_cents, idempotency_key=None):
        self.calls += 1
        if self.reject:
            raise InvalidRefund("amount is more than the original payment")
        if self.fail_first_calls > 0:
            self.fail_first_calls -= 1
            raise ProcessorTimeout("no response from processor")

        if idempotency_key is None or idempotency_key not in self._seen_keys:
            self.refunds.append((payment_id, amount_cents))
            if idempotency_key is not None:
                self._seen_keys.add(idempotency_key)

        if self.lose_first_responses > 0:
            self.lose_first_responses -= 1
            raise ProcessorTimeout("no response from processor")
        return {"status": "succeeded", "payment_id": payment_id}
