import logging
import time

from refund_service.config import REFUND_MAX_ATTEMPTS, REFUND_RETRY_DELAY_SECONDS
from refund_service.errors import RefundFailed

log = logging.getLogger(__name__)


class RefundService:
    def __init__(self, processor):
        self.processor = processor

    def issue_refund(self, payment_id, amount_cents):
        if amount_cents <= 0:
            raise ValueError("refund amount must be positive")

        for attempt in range(REFUND_MAX_ATTEMPTS):
            try:
                return self.processor.refund(payment_id, amount_cents)
            except Exception as e:
                log.warning(
                    "refund attempt %d failed for payment %s: %s",
                    attempt + 1, payment_id, e,
                )
                time.sleep(REFUND_RETRY_DELAY_SECONDS * attempt)

        raise RefundFailed(f"refund for {payment_id} failed after {REFUND_MAX_ATTEMPTS} attempts")
