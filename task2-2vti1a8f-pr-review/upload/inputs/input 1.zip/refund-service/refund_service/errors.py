class ProcessorTimeout(Exception):
    """The processor didn't answer in time. The refund may or may not have gone through."""


class InvalidRefund(Exception):
    """The processor rejected the refund, e.g. the amount is more than what was paid."""


class RefundFailed(Exception):
    pass
