PROCESSOR_TIMEOUT_SECONDS = 10

# retry refunds when the processor doesn't answer
REFUND_MAX_ATTEMPTS = 3
REFUND_RETRY_DELAY_SECONDS = 2
